This directory contains the code for support of the MIF format.
